function WelcomeMessage() {
    return (
        <div>
            <p>This is a simple JSX component.</p>
        </div>
    );
}

export default WelcomeMessage;
